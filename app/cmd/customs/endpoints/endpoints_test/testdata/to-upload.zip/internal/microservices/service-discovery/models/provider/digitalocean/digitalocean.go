package digitalocean

import "tde/internal/microservices/service-discovery/models/services"

type Droplet struct {
	Backups            bool     `json:"backups"`              // false,
	CreatedAt          string   `json:"created_at"`           // "2023-04-25T18:37:17Z",
	Disk               int      `json:"disk"`                 // 25,
	GracefulShutdown   bool     `json:"graceful_shutdown"`    // false,
	Id                 string   `json:"id"`                   // "352374631",
	Image              string   `json:"image"`                // "130693675",
	Ipv4Address        string   `json:"ipv4_address"`         // "46.101.129.10",
	Ipv4AddressPrivate string   `json:"ipv4_address_private"` // "10.150.0.2",
	Ipv6               bool     `json:"ipv6"`                 // true,
	Ipv6Address        string   `json:"ipv6_address"`         // "2a03:b0c0:3:d0::e29:5001",
	Locked             bool     `json:"locked"`               // false,
	Memory             int      `json:"memory"`               // 1024,
	Monitoring         bool     `json:"monitoring"`           // true,
	Name               string   `json:"name"`                 // "thesis-evolver-0",
	PriceHourly        float64  `json:"price_hourly"`         // 0.00893,
	PriceMonthly       int      `json:"price_monthly"`        // 6,
	PrivateNetworking  bool     `json:"private_networking"`   // true,
	Region             string   `json:"region"`               // "fra1",
	ResizeDisk         bool     `json:"resize_disk"`          // false,
	Size               string   `json:"size"`                 // "s-1vcpu-1gb",
	SshKeys            []string `json:"ssh_keys"`             // ["42:75:b8:ad:c1:76:4b:58:07:ec:e9:85:66:27:9b:e6"],
	Status             string   `json:"status"`               // "active",
	Tags               []string `json:"tags"`                 // ["thesis", "thesis-evolver"],
	Timeouts           int      `json:"timeouts"`             // null,
	Urn                string   `json:"urn"`                  // "do:droplet:352374631",
	UserData           string   `json:"user_data"`            // null,
	Vcpus              int      `json:"vcpus"`                // 1,
	VolumeIds          []string `json:"volume_ids"`           // [],
	VpcUuid            string   `json:"vpc_uuid"`             // "c3d39a86-99fa-4e2d-86ab-e71b18215b1e"
	// DropletAgent       string `json:"droplet_agent"`        // null,
}

type VPC struct {
	CreatedAt   string `yaml:"created_at"`  // "2023-05-20 06:49:46 +0000 UTC",
	Default     bool   `yaml:"default"`     // false,
	Description string `yaml:"description"` // "",
	Id          string `yaml:"id"`          // "d7576efa-6236-43a3-8c75-eb52299b60d8",
	IpRange     string `yaml:"ip_range"`    // "10.150.0.0/20",
	Name        string `yaml:"name"`        // "vpc",
	Region      string `yaml:"region"`      // "fra1",
	Timeouts    string `yaml:"timeouts"`    // null,
	Urn         string `yaml:"urn"`         // "do:vpc:d7576efa-6236-43a3-8c75-eb52299b60d8"
}

type Region struct {
	Services map[services.ServiceName][]Droplet `yaml:"services"`
	VPC      VPC                                `yaml:"vpc"`
}

func (r *Region) ListPrivateIPs(service services.ServiceName) (ips []string) {
	if hosts, ok := r.Services[service]; ok {
		for _, host := range hosts {
			ips = append(ips, host.Ipv4AddressPrivate)
		}
	}
	return
}

type RegionName string

type Digitalocean map[RegionName]Region

func (do *Digitalocean) ListPrivateIPs(service services.ServiceName) (ips []string) {
	for _, region := range *do {
		ips = append(ips, region.ListPrivateIPs(service)...)
	}
	return
}
