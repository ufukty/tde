package services

type ServiceName string

const (
	ApiGateway = "api_gateway"
	Customs    = "customs"
	Evolver    = "evolver"
	Runner     = "runner"
)
