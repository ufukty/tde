package router

var publicCertPath = "/etc/ssl/certs/localhost.crt"
var privateCertPath = "/etc/ssl/private/localhost.key"
