package node_constructor

var AllowedPackagesToImport = []string{"fmt", "strings", "math"}
