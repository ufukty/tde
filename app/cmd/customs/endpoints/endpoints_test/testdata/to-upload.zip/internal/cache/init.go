package cache

var (
	AST ASTCache
)

func init() {
	AST = ASTCache{}
}
