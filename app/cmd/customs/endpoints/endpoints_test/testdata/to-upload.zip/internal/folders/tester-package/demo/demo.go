package demo

func WordReverse(in string) string {
	return ""
}
