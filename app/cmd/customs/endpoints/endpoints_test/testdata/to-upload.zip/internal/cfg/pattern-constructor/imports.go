package pattern_constructor

// - TODO: Import a package
// - TODO: Access to components that are defined in imported packages:
//   - TODO: functions
//   - TODO: types
//     - TODO: aliases
//     - TODO: structs
//     - TODO: interfaces
