package router

var publicCertPath = "certificates/localhost.crt"  // run the binary from module root
var privateCertPath = "certificates/localhost.key" // run the binary from module root
