//go:build tools
// +build tools

package tools

import (
	_ "golang.org/x/tools/cmd/stringer"
)
