package main

type AccountParameters struct {
	RemainingCredits int
}
