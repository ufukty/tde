package knapsack

func Knapsack(w []float64, p []float64) []int {
	placement := []int{}
	return placement
}
