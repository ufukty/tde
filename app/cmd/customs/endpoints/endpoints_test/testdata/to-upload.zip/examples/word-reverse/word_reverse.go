package word_reverse

func WordReverse(w string) string {
	return ""
}
